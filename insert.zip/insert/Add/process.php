<?php include ('../connect/connect.php');?>
<?php 

	$id = $_POST['id'];
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$dep_id = $_POST['dep_id'];

	mysqli_query ($connect ,"INSERT INTO student (id,first_name,last_name,dep_id)
			VALUES ('$id','$first_name','$last_name','$dep_id')");	
?>

