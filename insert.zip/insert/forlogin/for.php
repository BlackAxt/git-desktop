<?php
	// Connect to the MySQL database
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "mydb";

	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	}

	// Get the username and password from the form submission
	$username = $_POST['username'];
	$password = $_POST['password'];

	// Check if the username and password are valid
	$sql = "SELECT * FROM users WHERE username='$username' AND password='$password'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
	    // Login successful, redirect to the dashboard
	    header("Location: dashboard.php");
	    exit();
	} else {
	    // Login failed, show an error message
	    echo "Invalid username or password";
	}

	$conn->close();
?>
